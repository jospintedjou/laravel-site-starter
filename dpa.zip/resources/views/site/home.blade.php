@extends('layouts.app-site')

@section('content')
<section id="about" class="about-mf sect-pt4 route">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="box-shadow-full">
                    <div class="row">
                        <div class="col-md-6 col-sm-12" style="background-image: url({{asset('theme/img/bg-showcase-3.PNG')}}); background-size: cover; min-height: 50vh">
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="about-me pt-4 pt-md-0">
                                <div class="title-box-2">
                                    <h5 class="title-left">
                                        A propos
                                    </h5>
                                </div>
                                <p class="lead">
                                    La Dev Passion Academy est une academie digitale née du soucis d'impulser un engouement plus grand dans les nouvelles technologies du digital en Afrique.
                                    Elle se déploie sur deux volets: la formation des développeurs web opérationnels et les services du digital avec un accent particulier sur la qualité du rendu.
                                </p>
                                <div class="skill-mf">
                                    <p class="title-s">Compétences</p>
                                    <span>Formations digitales</span> <span class="pull-right">85%</span>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                    <span>Consultations</span> <span class="pull-right">75%</span>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                    <span>Web Design</span> <span class="pull-right">50%</span>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                    <span>Developpement web</span> <span class="pull-right">90%</span>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: 90%" aria-valuenow="90" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--/ Section Services Star /-->
<section id="service" class="services-mf route">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="title-box text-center">
                    <h3 class="title-a">
                        Services
                    </h3>
                    <p class="subtitle-a">
                        Nous offrons une palette de services
                    </p>
                    <div class="line-mf"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="service-box">
                    <div class="service-ico">
                        <span class="ico-circle"><i class="ion-monitor"></i></span>
                    </div>
                    <div class="service-content">
                        <h2 class="s-title">Formations digitales</h2>
                        <p class="s-description text-center">
                            Vous rêvez de devenir developpeur web opérationnel, nous avons taillé pour vous une formation rapide et complète qui vous initie aux technologies nécessaires à la création des sites web et applications web.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="service-box">
                    <div class="service-ico">
                        <span class="ico-circle"><i class="ion-code-working"></i></span>
                    </div>
                    <div class="service-content">
                        <h2 class="s-title">Développement Web</h2>
                        <p class="s-description text-center">
                            Besoin d'un site web pour votre entreprise? Nos équipe façonne pour vous des sites web professionnels à votre images habillés à vos couleurs.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="service-box">
                    <div class="service-ico">
                        <span class="ico-circle"><i class="ion-camera"></i></span>
                    </div>
                    <div class="service-content">
                        <h2 class="s-title">Design Web</h2>
                        <p class="s-description text-center">
                            Votre site internet n'a jamais aussi bien reflété ce que vous offrez. Nous produisons des designs personnalisés et uniques à vos goûts et convenances.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="service-box">
                    <div class="service-ico">
                        <span class="ico-circle"><i class="ion-android-phone-portrait"></i></span>
                    </div>
                    <div class="service-content">
                        <h2 class="s-title">Responsive Design</h2>
                        <p class="s-description text-center">
                            L'ère du digital se vit sur différents appareils. Nous utilisons les dernières technologies pour créer des sites accéssibles depuis des smartphones, tablettes et des PCs .
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="service-box">
                    <div class="service-ico">
                        <span class="ico-circle"><i class="ion-paintbrush"></i></span>
                    </div>
                    <div class="service-content">
                        <h2 class="s-title">Graphic Design</h2>
                        <p class="s-description text-center">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni adipisci eaque autem fugiat! Quia,
                            provident vitae! Magni
                            tempora perferendis eum non provident.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="service-box">
                    <div class="service-ico">
                        <span class="ico-circle"><i class="ion-stats-bars"></i></span>
                    </div>
                    <div class="service-content">
                        <h2 class="s-title">Développement mobile</h2>
                        <p class="s-description text-center">
                            Le taux d'utilisation de smartphones est sans cesse grandissant. Votre application mobile facilite l'accès à vos servies pour vos clients. Faites construire par des proessionnels.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Section Services End /-->

<div class="section-counter paralax-mf bg-image" style="background-image: url({{asset('theme/img/counters-bg.jpg')}})">
        <div class="overlay-mf"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-3 col-lg-3">
                    <div class="counter-box">
                        <div class="counter-ico">
                            <span class="ico-circle"><i class="ion-checkmark-round"></i></span>
                        </div>
                        <div class="counter-num">
                            <p class="counter">28</p>
                            <span class="counter-text">TRAVAUX TERMINES</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-lg-3">
                    <div class="counter-box pt-4 pt-md-0">
                        <div class="counter-ico">
                            <span class="ico-circle"><i class="ion-ios-calendar-outline"></i></span>
                        </div>
                        <div class="counter-num">
                            <p class="counter">07</p>
                            <span class="counter-text">D'ANNEES D'EXPERIENCE</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-lg-3">
                    <div class="counter-box pt-4 pt-md-0">
                        <div class="counter-ico">
                            <span class="ico-circle"><i class="ion-ios-people"></i></span>
                        </div>
                        <div class="counter-num">
                            <p class="counter">26</p>
                            <span class="counter-text">CLIENTS</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-lg-3">
                    <div class="counter-box pt-4 pt-md-0">
                        <div class="counter-ico">
                            <span class="ico-circle"><i class="ion-ribbon-a"></i></span>
                        </div>
                        <div class="counter-num">
                            <p class="counter">20</p>
                            <span class="counter-text">ETUDIANTS FORMES</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--/ Section Portfolio Star /-->
<section id="work" class="portfolio-mf sect-pt4 route">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="title-box text-center">
                    <h3 class="title-a">
                        Projets réalisés
                    </h3>
                    <p class="subtitle-a">
                        Quelques unes de nos réalisations
                    </p>
                    <div class="line-mf"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="work-box">
                    <a href="{{asset('theme/img/mbengshop.png')}}" data-lightbox="gallery-mf">
                        <div class="work-img">
                            <img src="{{asset('theme/img/mbengshop.png')}}" alt="" class="img-fluid">
                        </div>
                        <div class="work-content">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h2 class="w-title">Mbengshop</h2>
                                    <div class="w-more">
                                        <span class="w-ctegory">Développement web</span> / <span class="w-date"> Avr. 2020</span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="w-like">
                                        <span class="ion-ios-plus-outline"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box">
                    <a href="{{asset('theme/img/acireded.png')}}" data-lightbox="gallery-mf">
                        <div class="work-img">
                            <img src="{{asset('theme/img/acireded.png')}}" alt="" class="img-fluid">
                        </div>
                        <div class="work-content">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h2 class="w-title">ACIREDED</h2>
                                    <div class="w-more">
                                        <span class="w-ctegory">Développement web</span> / <span class="w-date">Dec. 2019</span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="w-like">
                                        <span class="ion-ios-plus-outline"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box">
                    <a href="{{asset('theme/img/switlish.jpeg')}}" data-lightbox="gallery-mf">
                        <div class="work-img">
                            <img src="{{asset('theme/img/switlish-preview.jpeg')}}" alt="" class="img-fluid">
                        </div>
                        <div class="work-content">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h2 class="w-title">Switlish</h2>
                                    <div class="w-more">
                                        <span class="w-ctegory">Dévelopement mobile</span> / <span class="w-date"> Sep. 2018</span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="w-like">
                                        <span class="ion-ios-plus-outline"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box">
                    <a href="{{asset('theme/img/work-4.jpg')}}" data-lightbox="gallery-mf">
                        <div class="work-img">
                            <img src="{{asset('theme/img/work-4.jpg')}}" alt="" class="img-fluid">
                        </div>
                        <div class="work-content">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h2 class="w-title">Bindo Laro Cado</h2>
                                    <div class="w-more">
                                        <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="w-like">
                                        <span class="ion-ios-plus-outline"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box">
                    <a href="{{asset('theme/img/work-5.jpg')}}" data-lightbox="gallery-mf">
                        <div class="work-img">
                            <img src="{{asset('theme/img/work-5.jpg')}}" alt="" class="img-fluid">
                        </div>
                        <div class="work-content">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h2 class="w-title">Studio Lena Mado</h2>
                                    <div class="w-more">
                                        <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="w-like">
                                        <span class="ion-ios-plus-outline"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box">
                    <a href="img/work-6.jpg" data-lightbox="gallery-mf">
                        <div class="work-img">
                            <img src="{{asset('theme/img/work-6.jpg')}}" alt="" class="img-fluid">
                        </div>
                        <div class="work-content">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h2 class="w-title">Studio Big Bang</h2>
                                    <div class="w-more">
                                        <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2017</span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="w-like">
                                        <span class="ion-ios-plus-outline"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>
<!--/ Section Portfolio End /-->

<!--/ Section Testimonials Star /-->
<div class="testimonials paralax-mf bg-image" style="background-image: url({{asset('theme/img/overlay-bg.jpg')}})">
    <div class="overlay-mf"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div id="testimonial-mf" class="owl-carousel owl-theme">
                    <div class="testimonial-box">
                        <div class="author-test">
                            <img src="{{asset('theme/img/testimonial-2.jpg')}}" alt="" class="rounded-circle b-shadow-a">
                            <span class="author">Ivan pueugueu</span>
                        </div>
                        <div class="content-test">
                            <p class="description lead">
                                J'ai sollicité Dev Passion Academy pour la création d'un site internet. Au vu du travail de qualité
                                qui a été fourni et le respect des delais, je recommande Dev Passion Academy. Elle est fiable et sérieuse.
                            </p>
                            <span class="comit"><i class="fa fa-quote-right"></i></span>
                        </div>
                    </div>
                    <div class="testimonial-box">
                        <div class="author-test">
                            <img src="{{asset('theme/img/testimonial-4.jpg')}}" alt="" class="rounded-circle b-shadow-a">
                            <span class="author">Pamela Djeudjui</span>
                        </div>
                        <div class="content-test">
                            <p class="description lead">
                                J'ai suivi une formation en développement web à la Dev Passion Academy dans le but de m'enrichir
                                intellectuellement et augmenter mes chances dans le monde professionnel. Je recommande cettef formation!
                            </p>
                            <span class="comit"><i class="fa fa-quote-right"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--/ Section Blog Star /-->
<section id="blog" class="blog-mf sect-pt4 route">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="title-box text-center">
                    <h3 class="title-a">
                        Blog
                    </h3>
                    <p class="subtitle-a">
                        Suivez les articles sur notre blog.
                    </p>
                    <div class="line-mf"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card card-blog">
                    <div class="card-img">
                        <a href="blog-single.html"><img src="{{asset('theme/img/post-1.jpg')}}" alt="" class="img-fluid"></a>
                    </div>
                    <div class="card-body">
                        <div class="card-category-box">
                            <div class="card-category">
                                <h6 class="category">Site web</h6>
                            </div>
                        </div>
                        <h3 class="card-title"><a href="blog-single.html">Quels outils pour un site de qualité?</a></h3>
                        <p class="card-description">
                            Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                            a pellentesque nec,
                            egestas non nisi.
                        </p>
                    </div>
                    <div class="card-footer">
                        <div class="post-author">
                            <a href="#">
                                <img src="{{asset('theme/img/testimonial-1.jpg')}}" alt="" class="avatar rounded-circle">
                                <span class="author">Jospin Tedjou</span>
                            </a>
                        </div>
                        <div class="post-date">
                            <span class="ion-ios-clock-outline"></span> 10 min
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-blog">
                    <div class="card-img">
                        <a href="blog-single.html"><img src="{{asset('theme/img/post-1.jpg')}}" alt="" class="img-fluid"></a>
                    </div>
                    <div class="card-body">
                        <div class="card-category-box">
                            <div class="card-category">
                                <h6 class="category">Web Design</h6>
                            </div>
                        </div>
                        <h3 class="card-title"><a href="blog-single.html">Quels outils pour un site de qualité?</a></h3>
                        <p class="card-description">
                            Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                            a pellentesque nec,
                            egestas non nisi.
                        </p>
                    </div>
                    <div class="card-footer">
                        <div class="post-author">
                            <a href="#">
                                <img src="{{asset('theme/img/testimonial-2.jpg')}}" alt="" class="avatar rounded-circle">
                                <span class="author">Jospin Tedjou</span>
                            </a>
                        </div>
                        <div class="post-date">
                            <span class="ion-ios-clock-outline"></span> 10 min
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-blog">
                    <div class="card-img">
                        <a href="blog-single.html"><img src="{{asset('theme/img/post-3.jpg')}}" alt="" class="img-fluid"></a>
                    </div>
                    <div class="card-body">
                        <div class="card-category-box">
                            <div class="card-category">
                                <h6 class="category">Web Design</h6>
                            </div>
                        </div>
                        <h3 class="card-title"><a href="blog-single.html">Les promesses des applications mobiles</a></h3>
                        <p class="card-description">
                            Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                            a pellentesque nec,
                            egestas non nisi.
                        </p>
                    </div>
                    <div class="card-footer">
                        <div class="post-author">
                            <a href="#">
                                <img src="{{asset('theme/img/testimonial-2.jpg')}}" alt="" class="avatar rounded-circle">
                                <span class="author">Frtz Kenne</span>
                            </a>
                        </div>
                        <div class="post-date">
                            <span class="ion-ios-clock-outline"></span> 10 min
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Section Blog End /-->

@endsection