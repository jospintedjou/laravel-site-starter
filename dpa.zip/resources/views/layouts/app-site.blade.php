<!DOCTYPE html>
<html lang="fr">
<head>
    {!! Meta::toHtml() !!}
    <!--meta charset="utf-8"-->
    <title>Dev Passion Academy</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <!--meta content="" name="keywords">
    <meta content="" name="description"-->
    <!--meta_tags-->

    <!-- Favicons -->
    <link href="{{asset('theme/img/favicon.png')}}" rel="icon">
    <link href="{{asset('theme/img/favicon.png')}}" rel="apple-touch-icon">

    <!-- Bootstrap CSS File -->
    <link href="{{asset('theme/lib/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="{{asset('theme/lib/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
    <link href="{{asset('theme/lib/animate/animate.min.css')}}" rel="stylesheet">
    <link href="{{asset('theme/lib/ionicons/css/ionicons.min.css')}}" rel="stylesheet">
    <link href="{{asset('theme/lib/owlcarousel/assets/owl.carousel.min.css')}}" rel="stylesheet">
    <link href="{{asset('theme/lib/lightbox/css/lightbox.min.css')}}" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="{{asset('theme/css/style.css')}}" rel="stylesheet">

        <style>
            .whatsapp-icon{
                position: fixed;
                bottom: 100px;
                right: 9px;
                cursor: pointer;
                z-index: 99999999;
            }
            .whatsapp-icon img{
                width: 56px;
                /*height:: 60px;*/
            }
        </style>
</head>

<body id="page-top">

<!--/ Nav Star /-->
<nav class="navbar navbar-b navbar-trans navbar-expand-md fixed-top" id="mainNav">
    <div class="container">
        <a class="navbar-brand js-scroll" href="#page-top">
            DevPassionAcademy
        </a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault"
                aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <div class="navbar-collapse collapse justify-content-end" id="navbarDefault">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link js-scroll active" href="#home">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll" href="#about">A Propos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll" href="#service">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll" href="#work">Réalisations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll" href="#blog">Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll" href="#contact">Contactez-nous</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!--/ Nav End /-->

<!--/ Intro Skew Star /-->
<div id="home" class="intro route bg-image" style="background-image: url({{asset('theme/img/intro-bg.jpg')}})">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
        <div class="table-cell">
            <div class="container">
                <!--<p class="display-6 color-d">Hello, world!</p>-->
                <h1 class="intro-title mb-4">Services Web & Formations</h1>
                <p class="intro-subtitle"><span class="text-slider-items">Développement Web,Design Web, Développement Mobile, Bases de Données</span><strong class="text-slider"></strong></p>
                 <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#contact" role="button">Contactez-nous</a></p>
                <a class="whatsapp-icon" href="https://api.whatsapp.com/send?phone=237694680790">
                    <img src="{{asset('images/whatsapp-logo.svg.png')}}" alt="logo whatsapp">
                </a>
            </div>
        </div>
    </div>
</div>
<!--/ Intro Skew End /-->

@yield('content')
<!--/ Section Contact-Footer Star /-->
<section class="paralax-mf footer-paralax bg-image sect-mt4 route" style="background-image: url({{asset('img/overlay-bg.jpg')}})">
    <div class="overlay-mf"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="contact-mf">
                    <div id="contact" class="box-shadow-full">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="title-box-2">
                                    <h5 class="title-left">
                                        Envoyez nous un message
                                    </h5>
                                </div>
                                <div>
                                    <form action="{!! route('contact') !!}" method="post" class="contactForm">
                                        @csrf
                                        <div id="sendmessage">Votre message a bien été envoyé, merci!</div>
                                        <div id="errormessage"></div>
                                        <div class="row">
                                            <div class="col-md-12 mb-3">
                                                <div class="form-group">
                                                    <input type="text" name="name" class="form-control" id="name" placeholder="Votre Nom" data-rule="minlen:4" data-msg="Entrez au moins 4 caractères pour le nom." />
                                                    <div class="validation"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 mb-3">
                                                <div class="form-group">
                                                    <input type="email" class="form-control" name="email" id="email" placeholder="Votre Email" data-rule="email" data-msg="Entrez une adresse mail valide" />
                                                    <div class="validation"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 mb-3">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Sujet" data-rule="minlen:4" data-msg="Entrez au moins 8 caractères pour le sujet."/>
                                                    <div class="validation"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 mb-3">
                                                <div class="form-group">
                                                    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Ecrivez nous un message" placeholder="Message"></textarea>
                                                    <div class="validation"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <button type="submit" class="button button-a button-big button-rouded">Envoyer</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="title-box-2 pt-4 pt-md-0">
                                    <h5 class="title-left">
                                        Contactez nous
                                    </h5>
                                </div>
                                <div class="more-info">
                                    <p class="lead">
                                        Pour en savoir plus sur ce que nous offrons ou pour solliciter nos services, contactez-nous et nous nous ferons un plaisir de vous répondre.
                                    </p>
                                    <ul class="list-ico">
                                        <!--li><span class="ion-ios-location"></span> 329 WASHINGTON ST BOSTON, MA 02108</li-->
                                        <li><span class="ion-ios-telephone"></span> (+237) 694680790/695694220</li>
                                        <li><span class="ion-email"></span> contact@devpassionacademy.com</li>
                                    </ul>
                                </div>
                                <div class="socials">
                                    <ul>
                                        <li><a href="https://fecebook.com/webdevinitiation"><span class="ico-circle"><i class="ion-social-facebook"></i></span></a></li>
                                        <li><a href="http://youtube.ocm/devpassionacademy"><span class="ico-circle"><i class="ion-social-youtube"></i></span></a></li>
                                        <li><a href=""><span class="ico-circle"><i class="ion-social-instagram"></i></span></a></li>
                                        <li><a href=""><span class="ico-circle"><i class="ion-social-twitter"></i></span></a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-12">
                                    <img class="img-fluid" src="{{asset('theme/img/favicon.png')}}" alt="logo DPA">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="copyright-box">
                        <p class="copyright">&copy; Copyright <strong>DevPassionAcademy</strong>. Tous droits réservés</p>
                        <div class="credits">
                            <!--
                              All the links in the footer should remain intact.
                              You can delete the links only if you purchased the pro version.
                              Licensing information: https://bootstrapmade.com/license/
                              Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=DevFolio
                            -->
                            <!--a href="https://bootstrapmade.com/">BootstrapMade</a-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</section>
<!--/ Section Contact-footer End /-->

<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
<div id="preloader"></div>

<!-- JavaScript Libraries -->
<script src="{{asset('theme/lib/jquery/jquery.min.js')}}"></script>
<script src="{{asset('theme/lib/jquery/jquery-migrate.min.js')}}"></script>
<script src="{{asset('theme/lib/popper/popper.min.js')}}"></script>
<script src="{{asset('theme/lib/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('theme/lib/easing/easing.min.js')}}"></script>
<script src="{{asset('theme/lib/counterup/jquery.waypoints.min.js')}}"></script>
<script src="{{asset('theme/lib/counterup/jquery.counterup.js')}}"></script>
<script src="{{asset('theme/lib/owlcarousel/owl.carousel.min.js')}}"></script>
<script src="{{asset('theme/lib/lightbox/js/lightbox.min.js')}}"></script>
<script src="{{asset('theme/lib/typed/typed.min.js')}}"></script>
<!-- Contact Form JavaScript File -->
<script src="{{asset('theme/contactform/contactform.js')}}"></script>

<!-- Template Main Javascript File -->
<script src="{{asset('theme/js/main.js')}}"></script>

</body>
</html>
